A Pen created at CodePen.io. You can find this one at https://codepen.io/sharline_gruenzner20/pen/wQExdN.

 Responsive Photography Portfolio using the w3.css framework